// Loop Simulator core logic goes here
